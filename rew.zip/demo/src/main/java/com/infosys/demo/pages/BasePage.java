package com.infosys.demo.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.infosys.demo.hooks.Hooks;

public class BasePage {
	 protected WebDriver driver;

	    public BasePage(WebDriver driver) {
	        this.driver = Hooks.getDriver();
	        PageFactory.initElements(driver, this);
	    }

	    protected void clickButton(WebElement element) {
	        element.click();
	    }

	    protected void sendKeys(WebElement element, String text) {
	        element.clear();
	        element.sendKeys(text);
	    }
}
