package com.infosys.demo.hooks;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

import com.infosys.demo.utils.CommonUtils;
import com.infosys.demo.utils.PageObjectManager;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {

	private static WebDriver driver;
	private static PageObjectManager pageObjectManager;

	@Before
	public void setup() {
		String browser = CommonUtils.getBrowser();

		if ("chrome".equalsIgnoreCase(browser)) {
			ChromeOptions ops = new ChromeOptions();
			ops.addArguments("--remote-allow-origins=*");
			driver = new ChromeDriver(ops);
		}

		else if ("edge".equalsIgnoreCase(browser)) {
			EdgeOptions edgeOptions = new EdgeOptions();
			edgeOptions.addArguments("--remote-allow-origins=*");
			driver = new EdgeDriver(edgeOptions);
		}

		driver.manage().window().maximize();
		pageObjectManager = new PageObjectManager(driver);
	}

	@After
	public void tearDown() {
		// Close the WebDriver at the end of the test
		if (driver != null) {
			driver.quit();
		}
	}

	public static WebDriver getDriver() {
		return driver;
	}

	public static PageObjectManager getPageObjectManager() {
		return pageObjectManager;
	}
}
