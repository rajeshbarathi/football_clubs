package com.infosys.demo.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ApproverPage extends BasePage {

	@FindBy(id = "searchCaseId")
	private WebElement searchCaseIdField;

	@FindBy(id = "approveButton")
	private WebElement approveButton;

	public ApproverPage(WebDriver driver) {
		super(driver);
	}

	   public void searchAndApproveUser(String caseId) {
	        sendKeys(searchCaseIdField, caseId);
	        clickButton(approveButton);
	    }
}


