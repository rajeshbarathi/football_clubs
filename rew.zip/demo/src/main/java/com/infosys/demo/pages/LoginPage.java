package com.infosys.demo.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.infosys.demo.utils.CommonUtils;

public class LoginPage extends BasePage {

	@FindBy(id = "username")
	private WebElement usernameField;

	@FindBy(id = "password")
	private WebElement passwordField;

	@FindBy(id = "loginButton")
	private WebElement loginButton;

	public LoginPage(WebDriver driver) {
		super(driver);
	}
	
	public void navigateToLoginPage() {
        driver.get(CommonUtils.getUrl());
    }

	public void login(String email, String password) {
		sendKeys(usernameField, email);
		sendKeys(passwordField, password);
		clickButton(loginButton);
	}
}
