package com.infosys.demo.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;


public class CommonUtils {

	private static Properties configProperties;

    static {
        configProperties = new Properties();
        try (FileInputStream input = new FileInputStream("src/main/java/com/infosys/demo/data/config.properties")) {
            configProperties.load(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getBrowser() {
        return configProperties.getProperty("browser");
    }

    public static String getUrl() {
        return configProperties.getProperty("url");
    }
}

