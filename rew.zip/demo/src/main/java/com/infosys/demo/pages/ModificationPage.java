package com.infosys.demo.pages;

import org.openqa.selenium.WebDriver;

public class ModificationPage {

	public ModificationPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
	}

}
