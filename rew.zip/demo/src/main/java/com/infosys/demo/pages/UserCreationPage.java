package com.infosys.demo.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UserCreationPage {
    
    
    @FindBy(id = "details")
    private WebElement detailsField;

    @FindBy(id = "createButton")
    private WebElement createButton;

    public UserCreationPage(WebDriver driver) {
    }

    public void fillCaseDetails(WebDriver driver) {
    }

    public boolean isCaseIDGenerated(WebDriver driver) {
        // Code to check if a new caseID is generated
        return true;
    }

}
