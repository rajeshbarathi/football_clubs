package com.infosys.demo.utils;

import org.openqa.selenium.WebDriver;

import com.infosys.demo.pages.ApproverPage;
import com.infosys.demo.pages.LoginPage;
import com.infosys.demo.pages.ModificationPage;
import com.infosys.demo.pages.UserCreationPage;

public class PageObjectManager {
	private WebDriver driver;

    private LoginPage loginPage;
    private ApproverPage approverPage;
    private ModificationPage modificationPage;
    private UserCreationPage userCreationPage;
    
    // Add other page classes as needed

    public PageObjectManager(WebDriver driver) {
        this.driver = driver;
    }

    public LoginPage getLoginPage() {
        return (loginPage == null) ? loginPage = new LoginPage(driver) : loginPage;
    }

    public ApproverPage getApproverPage() {
        return (approverPage == null) ? approverPage = new ApproverPage(driver) : approverPage;
    }
    
    public ModificationPage getModificationPage() {
        return (modificationPage == null) ? modificationPage = new ModificationPage(driver) : modificationPage;
    }
    
    public UserCreationPage getUserCrationPage() {
        return (userCreationPage == null) ? userCreationPage = new UserCreationPage(driver) : userCreationPage;
    }
}
