package com.infosys.demo.stepdefinitions;

import io.cucumber.java.en.*;

public class ApproverStepsDefinitions {
	@Given("{string} is logged in")
	public void is_logged_in(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@When("{string} searches for case ID and approves the user")
	public void searches_for_case_id_and_approves_the_user(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@Then("User should be approved successfully")
	public void user_should_be_approved_successfully() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
}


