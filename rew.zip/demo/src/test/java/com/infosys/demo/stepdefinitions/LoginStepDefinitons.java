package com.infosys.demo.stepdefinitions;

import com.infosys.demo.hooks.Hooks;
import com.infosys.demo.pages.LoginPage;
import com.infosys.demo.utils.PageObjectManager;

import io.cucumber.java.en.*;

public class LoginStepDefinitons {
	
	 private PageObjectManager pom = Hooks.getPageObjectManager();
	 private LoginPage loginPage = pom.getLoginPage();

	@Given("the user is on the login page")
	public void the_user_is_on_the_login_page() {
		loginPage.navigateToLoginPage();
	}

	@When("User enters email {string} and password {string}")
	public void the_user_logs_in_with_valid_username_and_password(String email, String password) {
		loginPage.login(email, password);
	}

	@Then("the user should be logged in successfully")
	public void the_user_should_be_logged_in_successfully() {

	}
}
