package com.infosys.demo.stepdefinitions;

import io.cucumber.java.en.*;

public class UserCreationStepDefinitions {

	@Given("the user is logged in")
	public void the_user_is_logged_in() {
	}

	@When("the user fills details to create a new caseId")
	public void the_user_fills_details_to_create_a_new_case_id() {
	}

	@Then("a new caseId should be created successfully")
	public void a_new_case_id_should_be_created_successfully() {
		throw new io.cucumber.java.PendingException();
	}
}
