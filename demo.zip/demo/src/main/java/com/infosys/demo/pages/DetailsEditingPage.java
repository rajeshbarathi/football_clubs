package com.infosys.demo.pages;

public class DetailsEditingPage {

}
