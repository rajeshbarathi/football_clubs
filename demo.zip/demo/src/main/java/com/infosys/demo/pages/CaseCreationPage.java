package com.infosys.demo.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CaseCreationPage {
    
    
    @FindBy(id = "details")
    private WebElement detailsField;

    @FindBy(id = "createButton")
    private WebElement createButton;

    public CaseCreationPage(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    public void fillCaseDetails(WebDriver driver) {
        // Code to fill details for case creation
    }

    public boolean isCaseIDGenerated(WebDriver driver) {
        // Code to check if a new caseID is generated
        return true;
    }

    public void editCaseDetails(WebDriver driver, String customerNumber) {
        // Code to edit details based on customer number
        // For example, locate the details field by a different ID
        // driver.findElement(By.id("editedDetails")).sendKeys("Updated details");
    }
}
