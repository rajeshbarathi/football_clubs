package com.infosys.demo.hooks;

public class WebDriverHooks {

}
