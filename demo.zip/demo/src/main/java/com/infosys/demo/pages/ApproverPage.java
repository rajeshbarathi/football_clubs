package com.infosys.demo.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ApproverPage {

	@FindBy(id = "searchCaseId")
	private WebElement searchCaseIdField;

	@FindBy(id = "approveButton")
	private WebElement approveButton;

	public ApproverPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public void searchCaseID(WebDriver driver, String caseID) {
		searchCaseIdField.sendKeys(caseID);
		// Additional code for searching case ID
	}

	public void approveCase(WebDriver driver) {
		approveButton.click();
		// Additional code for approving the case
	}
}
