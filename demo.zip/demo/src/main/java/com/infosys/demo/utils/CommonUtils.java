package com.infosys.demo.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CommonUtils {


    private final WebDriver driver;

    public CommonUtils(WebDriver driver) {
        this.driver = driver;
    }

    public void clickElement(By locator) {
        WebElement element = driver.findElement(locator);
        element.click();
    }

    public void sendKeysToElement(By locator, String text) {
        WebElement element = driver.findElement(locator);
        element.sendKeys(text);
    }

    // Additional utility methods can be added as needed
}

