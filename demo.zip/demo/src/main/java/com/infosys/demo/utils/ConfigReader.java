package com.infosys.demo.utils;

public class ConfigReader {

}
