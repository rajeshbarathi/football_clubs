package com.infosys.demo.stepdefinitions;

import io.cucumber.java.en.*;

public class ApproverSteps {

	@Given("an approver logs in with valid credentials from Excel")
	public void an_approver_logs_in_with_valid_credentials_from_excel() {
	}

	@When("the approver searches for the caseID {string}")
	public void the_approver_searches_for_the_case_id(String string) {
	}

	@When("the approver approves the case")
	public void the_approver_approves_the_case() {
	}

	@Then("the case should be approved successfully")
	public void the_case_should_be_approved_successfully() {
	}

}
